const express = require('express');
const pdfRoutes = require('./routes/pdfRoutes');

const app = express();
const port = 3000;

// 中间件设置
app.use(express.json());
app.use(express.static('public'));  // 如果你有静态文件（如图片、CSS等）

// 使用路由
app.use('/water/report/monthly/use/monthly/use/pdf', pdfRoutes);

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});

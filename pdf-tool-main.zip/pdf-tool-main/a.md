


│
├── server.js           # 服务器入口文件
├── routes/             # 存放路由的文件夹
│   └── pdfRoutes.js    # PDF 路由
├── utils/              # 存放工具函数
│   └── pdfGenerator.js # 生成 PDF 的函数
├── static/             # 存放静态资源（如字体、图片等）
│   └── fonts/          # 字体文件夹
├── package.json        # 项目配置文件
├── .env                # 配置文件（可选）
└── README.md           # 项目说明文件

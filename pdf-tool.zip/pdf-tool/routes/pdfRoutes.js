const express = require('express');
const router = express.Router();
const { createPDF } = require('../utils/pdfGenerator');

//生成 water pdf
router.post('/', async (req, res) => {
  const data = req.body;
  console.log(data,'data');
  try {
    console.log('1')
    const pdfBuffer = await createPDF(data);

    console.log('success')

    res.contentType('application/pdf');
    res.send(pdfBuffer);  
  } 
  catch (error) 
  {
    console.log('error:',error)
    res.status(500).json({ 
        error: 'Failed to generate PDF',
        code:500,
        message: error
     });
  }
});

module.exports = router;

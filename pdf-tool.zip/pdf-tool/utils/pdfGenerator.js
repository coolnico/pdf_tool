const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// 生成 PDF 的函数
async function createPDF(data) {
  let propertyName = data && data.propertyName || '- -';
  let dataList = data && data.waterPrimaryDataMonthlyUseExportDtos || [];

  let startTime = data && data.startTime || '-';
  let endTime = data && data.endTime || '-';
  let unit = data && data.unit || 'Gals';
  let total = data && data.total || 0;
  
  const browser = await chromium.launch();
  const page = await browser.newPage();

  const currentDate = new Date().toISOString().split('T')[0]; 
  const rowsPerPage = 50;
  const HelixaBoldPath = path.resolve(__dirname, '../static/fonts/Helixa-Bold.ttf');
  const HelixaBoldPathBase64 = fs.readFileSync(HelixaBoldPath, 'base64');
  const HelixaPath = path.resolve(__dirname, '../static/fonts/Helixa-Regular.ttf');
  const HelixaPathBase64 = fs.readFileSync(HelixaPath, 'base64');

  function paginateData(data, rowsPerPage) {
    const pages = [];
    for (let i = 0; i < data.length; i += rowsPerPage) {
      pages.push(data.slice(i, i + rowsPerPage));
    }
    return pages;
  }

  let paginatedData = paginateData(dataList, rowsPerPage);

 let htmlContent = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Monthly Water Usage Report</title>
      <style>
            @font-face {
              font-family: 'Helixa-Bold';
              src: url('data:font/truetype;charset=utf-8;base64,${HelixaBoldPathBase64}') format('truetype');
          }

          @font-face {
              font-family: 'Helixa';
              src: url('data:font/truetype;charset=utf-8;base64,${HelixaPathBase64}') format('truetype');
          }

          .report {
              position: relative;
              background: #fff;
              width: 100%;
              height: 100%;
          }
          
          .page {
              padding: 0 60px;
              height: 1800px;
              width: 1275px;
              page-break-after: always;
          }
          
          .header {
              padding: 59px 0;
              display: flex;
              justify-content: space-between;
              color: #000000;
              font-size: 14px;
              font-family: 'Helixa-Bold';
          }
          
          .service-icon {
              width: 210px;
              height: 48px;
              object-fit: contain;
              margin-left: 21px;
          }
          
          .header-center {
              text-align: center;
          }
          
          .header-center div {
              font-size: 28px;
          }
          
          .header-center div:nth-child(1) {
              border-bottom: 1px solid #000;
              line-height: 25px;
          }
          
          .header-center div:nth-child(2) {
              font-size: 16px;
              margin-top: 8px;
          }
          
          .header-center div:nth-child(3) {
              font-size: 14px;
              margin-top: 32px;
          }
          
          .header-right {
              width: 210px;
              text-align: right;
              margin-top: 10px;
              font-size: 14px;
          }
          
          .table {
              position: relative;
          }
          
          .total {
              background: #EEEEEE;
              color: #000;
              font-size: 12px;
              border-top: 1px solid #000;
              text-align: right;
              padding: 0 14px;
              height: 46px;
              line-height: 46px;
              font-family: 'Helixa-Bold';
          }
          
          .tables {
              display: flex;
          }
          
          .table-header {
              background-color: #002584;
              color: #fff;
              height: 46px;
              font-size: 12px;
              text-align: center;
              font-family:'Helixa-Bold';
          }
          
          .table-cell {
              display: flex;
              justify-content: center;
              align-items: center;
              font-size: 12px;
              font-family:'Helixa';
          }
          
          .table-data {
              background: #fff;
              height: 32px;
              line-height: 32px;
              font-family:'Helixa';
          }
          
          .table-data:nth-child(odd) {
              background: #EEEEEE80;
          }
          
          .table-cell {
              text-align: center;
              padding: 0 30px;
              overflow: hidden;
              text-overflow: ellipsis;
              word-break: break-all;
              white-space: nowrap;
              font-size: 12px;
              font-family:'Helixa';
          }

          .table-cell-right {
              text-align: right;
              display: flex;
              justify-content: flex-end; 
              align-items: center; 
              padding: 0 30px;
          }
      </style>
  </head>
  <body>
  `;

  let pageCount = 1;
  for (const [pageIndex, pageData] of paginatedData.entries()) {
    //   let totalGallons = pageData.reduce((sum, row) => sum + parseFloat(row.difference), 0);
      let totalText = pageIndex === paginatedData.length - 1 ? `${total}` : 'Continue ...';
  
      htmlContent += `
          <div class="page">
              <div class="header">
                  <img class="service-icon" src="https://www.helloimg.com/i/2024/11/14/67356e2cceafa.png">
                  <div class="header-center">
                      <div>${propertyName}</div>
                      <div>Monthly Water Usage Report</div>
                      <div>From: ${startTime} to ${endTime}</div>
                  </div>
                  <div class="header-right">
                      <div>${currentDate}</div>
                      <div>Page ${pageCount} of ${paginatedData.length}</div>
                  </div>
              </div>
              <div class="table">
                  <div class="tables table-header">
                      <div class="table-cell" style="width: 80px; text-align: center;">#</div>
                      <div class="table-cell" style="width: 140px; text-align: center;">Building</div>
                      <div class="table-cell" style="width: 100px; text-align: center;">Unit</div>
                      <div class="table-cell" style="width: 160px; text-align: center;">Meter Number</div>
                      <div class="table-cell" style="width: 160px; text-align: center;">Start of the Period</div>
                      <div class="table-cell" style="width: 120px; text-align: center;">Starting Value<br>(${unit})</div>
                      <div class="table-cell" style="width: 160px; text-align: center;">End of the Period</div>
                      <div class="table-cell" style="width: 120px; text-align: center;">Ending Value<br>(${unit})</div>
                      <div class="table-cell" style="width: 120px; text-align: center;">Difference<br>(${unit})</div>
                  </div>
      `;

      // Add rows for this page
      pageData.forEach((row, index) => {
          htmlContent += `  
                  <div class="tables table-data">
                      <div class="table-cell" style="width: 80px;">${index + 1}</div>
                      <div class="table-cell" style="width: 140px;">${row.buildingName}</div>
                      <div class="table-cell" style="width: 100px;">${row.apartmentName}</div>
                      <div class="table-cell" style="width: 160px;">${row.deviceId}</div>
                      <div class="table-cell" style="width: 160px;">${row.startOfThePeriod}</div>
                      <div class="table-cell table-cell-right" style="width: 120px;">${row.startingValue}</div>
                      <div class="table-cell" style="width: 160px;">${row.endOfThePeriod}</div>
                      <div class="table-cell table-cell-right" style="width: 120px;">${row.endingValue}</div>
                      <div class="table-cell table-cell-right" style="width: 120px;">${row.difference}</div>
                  </div>
          `;
      });

      htmlContent += `
              <div class="total">${totalText}</div>
          </div>
      </div>
      `;

      pageCount++;
  }

  htmlContent += `
      </body>
      </html>
  `;

  await page.setContent(htmlContent);
  await page.waitForLoadState('load');

  // 生成文件流
  const pdfBuffer = await page.pdf({
    // path: 'Monthly Water Usage Report.pdf',
    width: '1700px',   // Increase the width if the content is getting cut off horizontally
    height: '2520px',  // Increase the height if the content is getting cut off vertically
    printBackground: true,
    scale: 1.8
  });

  await browser.close();

  return pdfBuffer;
}

module.exports = { createPDF };
